export default function Footer() {
  return (
    <div className="footer">
      © {new Date().getFullYear()} Home & Fashion Market · Handmade & curated items
    </div>
  );
}
